# -*- coding: utf-8 -*-
"""
Created on Sun Apr  4 17:03:26 2021

@author: 23dhisne
"""

import discord
import os
import random
from replit import db
from keep_alive import keep_alive
from market_draft import *
from discord.utils import get
import discord.ext
import discord.utils

"""
Items: Artifacts: (80%) Air Scepter Earth Scepter Fire Scepter Water Scepter Air Amulet Earth Amulet Fire Amulet Water Amulet Air Scroll Earth Scroll Fire Scroll Water Scroll Air Rune Earth Rune Fire Rune Water Rune Minerals: (20%) Ruby Emerald Aquamarine Topaz Diamond Amythyst Tools: Adventurer's Crown allows solo adventuring Warrior's Helm allows combat Miner's Pick allows mining Alchemist's Beaker allows Alchemy Mage's Robe makes one invincible to stealing Currency: Copper Silver (worth two copper) Gold (worth three copper)
"""

#variables
artifacts = ["Air Scepter", "Earth Scepter", "Fire Scepter", "Water Scepter", "Air Amulet", "Earth Amulet", "Fire Amulet", "Water Amulet", "Air Scroll", "Earth Scroll", "Fire Scroll", "Water Scroll", "Air Rune", "Earth Rune", "Fire Rune", "Water Rune"]
minerals = ["Ruby", "Emerald", "Aquamarine", "Topaz", "Diamond", "Amethyst"]
tools = ["Adventurers Crown", "Warriors Helm", "Miners Pick", "Alchemists Beaker", "Mages Robe"]
mPrices = db['Marketplace']
#mPrices={}   

def getItem(i):
  i = i.lower()
  if (" " in i):
      first = True
      i2 = i.split()
      i = ""
      for k in i2:
          if first==False:
              i += " "
          else:
              first = False
          i += k.capitalize()
  else:
      i = i.capitalize()
  return i

def getItemB(i):
  i = i.lower()
  if (" " in i):
      first = True
      i2 = i.split()
      i = ""
      for k in i2:
          if first==False:
              i += " "
          else:
              first = False
          i += k.capitalize()
  else:
      i = i.capitalize()
  if i in db['Marketplace']:
    return i
  else:
    return "error"

def sell_item(i,j,a,m):
    #mPrices = m
    return (enter_price(getItem(i),j,a,m))
    #exchange currency

def enter_price(i,j,a,m):
    #mPrices = m
    if i in db['Marketplace']:
        db['Marketplace'][i].append(int(j))
        db['Marketplace'][i].append(str(a))
        #print(mPrices[i])
    else:
        db['Marketplace'][i] = [int(j),str(a)]
    description = "Your item, " + i + ", has been put on the market at the price of " + str(j) + " copper! It is now waiting to be ordered."
    return description

def con_m():
  return mPrices

def display_items(guild):
    txt = ""
    if db['Marketplace'] != {}:
        for i in db['Marketplace']:
            for j in range(0,len(db['Marketplace'][i])-1,2):
                emojiname=i.lower()
                emojiname=emojiname.replace(" ", "")
                emoji = discord.utils.get(guild.emojis, name=emojiname)
                if emoji:
                  txt+=f"{emoji}"
                txt += " "
                txt += " " + i + ": "
                txt += str(db['Marketplace'][i][j]) + " copper\n"
                #print(db['Marketplace'][i])
    else:
        txt = "Unfortunately, the inventory is empty. Check back to see if more items are added!"
    #db["Marketplace"] = mPrices
    return(txt)
    
def checkPrice(item,m):
    #use gold first, then silver, then copper
    #create purchase function
    #list = db['Marketplace'].get('item')
    tiny = 1000000000
    mPrices = m
    li = mPrices[item]
    for k in range(0,len(li),2):
      if li[k] < tiny:
        tiny = li[k]
    return tiny

def get_seller(item,m):
    #use gold first, then silver, then copper
    #create purchase function
    #mPrices = m
    price = checkPrice(item,m)
    seller = ""
    for k in range(0,len(db['Marketplace'][item])-1,2):
      if db['Marketplace'][item][k] == price:
        seller = db['Marketplace'][item][k+1]
        return seller
        break

def buy_item(item,a,m):
    #use gold first, then silver, then copper
    #create purchase function
    #mPrices = m
    price = checkPrice(item,m)
    seller = ""
    for k in range(0,len(db['Marketplace'][item])-1,2):
      if db['Marketplace'][item][k] == price:
        break
    db['inv'+a].append(item)
    for x in range(0,price):
      db['inv'+get_seller(item,m)].append("Copper")
      db['inv'+a].remove("Copper")
    if len(db['Marketplace'][item])==2:
      db['Marketplace'].pop(item)
    else:
      del db['Marketplace'][item][k]
      del db['Marketplace'][item][k]
    #db["Marketplace"] = mPrices

def main_screen():
  pass

def go_market():
   pass

def clear():
  global mPrices
  mPrices={}