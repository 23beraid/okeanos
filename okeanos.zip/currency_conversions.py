#Inventory = ["Miner's Pick", "Copper", "Silver", "Gold", "Copper"]
#def Convert1AgTo2Cu():
#Inventory = ["Miner's Pick", "Copper", "Silver", "Gold", "Copper"]
from replit import db

def Convert1AgTo2Cu(Inventory,a):
	if "Silver" in Inventory:
		Inventory.remove("Silver")
		for x in range(0,2):
			Inventory.append("Copper")
		db['inv'+a] = Inventory
	return "Your Silver has successfuly been converted into 2 Copper!"

def Convert1AuTo3Cu(Inventory,a):
  if "Gold" in Inventory:
    Inventory.remove("Gold")
    for x in range(0,3):
      Inventory.append("Copper")
    db['inv'+a] = Inventory
  return "Your Gold has successfuly been converted into 3 Copper!"

def ConvertCu2Ag(Inventory,a):
	if "Silver" in Inventory:
		Inventory.remove("Copper")
		Inventory.append("Silver")
		db['inv'+a] = Inventory
	return "Your Copper has successfuly been converted into Silver!"

def ConvertAg2Au(Inventory,a):
  if "Silver" in Inventory:
    Inventory.remove("Silver")
    Inventory.append("Gold")
    db['inv'+a] = Inventory
  return "Your Silver has successfuly been converted into Gold!"
#Convert1AgTo2Cu()
#Convert1AuTo3Cu()