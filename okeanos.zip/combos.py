from replit import db
import discord
from discord.utils import get

arts = ['Air Scepter', 'Earth Scepter', 'Fire Scepter', 'Water Scepter', 'Air Amulet', 'Earth Amulet', 'Fire Amulet', 'Water Amulet', 'Air Scroll', 'Earth Scroll', 'Fire Scroll', 'Water Scroll', 'Air Rune', 'Earth Rune', 'Fire Rune', 'Water Rune']
mins = ['Ruby', 'Emerald', 'Aquamarine', 'Topaz', 'Diamond', 'Amethyst']
tools = ['Adventurers Crown', 'Warriors Helm', 'Mages Robe', 'Miners Pick', 'Alchemists Beaker']
curr = ['Copper', 'Silver', 'Gold']

def duplicates(arr1, arr2):
    a = arr1
    b = arr2
    c = []
    for x in a:
        for y in b:
            if x == y:
                c.append(x)
    c = sorted(c)
    b = sorted(b)
    if c == b:
        return True
    else:
        return False

def combineElements(user, combination):
    if 'museum'+str(user.id) not in db:
        db['museum'+str(user.id)]=[]
    needed = [combination + " Rune", combination + " Scroll", combination + " Scepter", combination + " Amulet"]
    combo = combination + " Combo"
    inventory=db['inv'+str(user.id)]
    museum=db['museum'+str(user.id)]
    if duplicates(inventory, needed) == True:
        for x in range(0, len(needed)):
            inventory.remove(needed[x])
        museum.append(combo)
        for x in range(0, 4):
            inventory.append('Gold')
        db['inv'+str(user.id)]=inventory
        db['museum'+str(user.id)]=museum
        house=db['house'+str(user.id)]
        db[house]+=20
        return "Successful combination of items. Your set has been donated to the museum for 4 gold and house points."
    else:
        return "You don't have the right items!"

def combineItems(user, combination):
    if 'museum'+str(user.id) not in db:
        db['museum'+str(user.id)]=[]
    needed = ["Air " + combination, "Earth " + combination, "Fire " + combination, "Water " + combination]
    combo = combination + " Combo"
    inventory=db['inv'+str(user.id)]
    museum=db['museum'+str(user.id)]
    
    if duplicates(inventory, needed) == True:
        for x in range(0, len(needed)):
            inventory.remove(needed[x])
        museum.append(combo)
        for x in range (0, 4):
            inventory.append('Gold')
        db['inv'+str(user.id)]=inventory
        db['museum'+str(user.id)]=museum
        house=db['house'+str(user.id)]
        db[house]+=20
        return "Successful combination of items. Your set has been donated to the museum for 4 gold and house points."
    else:
        return "You don't have the right items!"

def allItems(guild):
  finList = []
  for i in arts:
    txt=''
    emojiname=i.lower()
    emojiname=emojiname.replace(" ", "")
    emoji = discord.utils.get(guild.emojis, name=emojiname)
    txt+=f"{emoji}"
    txt += " "
    txt += " " + i + "\n"
    finList.append(f"{txt}")
  for i in mins:
    txt=''
    emojiname=i.lower()
    emojiname=emojiname.replace(" ", "")
    emoji = discord.utils.get(guild.emojis, name=emojiname)
    txt+=f"{emoji}"
    txt += " "
    txt += " " + i + "\n"
    finList.append(f"{txt}")
  for i in tools:
    txt=''
    emojiname=i.lower()
    emojiname=emojiname.replace(" ", "")
    emoji = discord.utils.get(guild.emojis, name=emojiname)
    txt+=f"{emoji}"
    txt += " "
    txt += " " + i + "\n"
    finList.append(f"{txt}")
  for i in curr:
    txt=''
    emojiname=i.lower()
    emojiname=emojiname.replace(" ", "")
    emoji = discord.utils.get(guild.emojis, name=emojiname)
    txt+=f"{emoji}"
    txt += " "
    txt += " " + i + "\n"
    finList.append(f"{txt}")
  print(finList)
  return finList

def doAlchemy(user, inputa, outputa):
    inputa=inputa.capitalize()
    outputa=outputa.capitalize()
    inventory=db['inv'+str(user.id)]
    minerals = ["Ruby", "Topaz", "Diamond", "Aquamarine", "Emerald", "Amethyst"]
    if "Alchemists Beaker" not in inventory:
        return "Alchemists beaker is required for alchemy"
    elif inputa not in minerals:
        return "The specified input is not a mineral. Be sure to specify input and output using o-alchemy <input>, <output>"
    elif outputa not in minerals:
        return "The specified output is not a mineral. Be sure to specify input and output using o-alchemy <input>, <output>"
    elif inputa not in inventory:
        return "The specified input could not be found in your inventory."
    else:
        inventory.remove(inputa)
        inventory.append(outputa)
        return "Your " + inputa + " is now " + outputa 
        db['inv'+str(user.id)]=inventory
