import discord
import os
import random
from replit import db
from keep_alive import keep_alive
from market_draft import *
from currency_conversions import *
from crafting import *
from mining import *
from combos import *
from stealing import *
from discord.utils import get
import discord.ext
import discord.utils
from discord.ext import commands
from discord.ext.commands.cooldowns import BucketType

#@commands.cooldown(rate,per,BucketType) 
# Limit how often a command can be used, (num per, seconds, BucketType.default/user/member/guild/channel/role)



#db["Marketplace"]={}
keys=db.keys()
'''
db["balance"]=0
db["bravery"]=0
db['brilliance']=0
'''
elements=['Fire', 'Water', 'Earth', 'Air']
items=['Amulet', 'Scepter', 'Rune', 'Scroll']


itemPoints={"Water Scepter": 10, "Earth Scepter": 10, "Fire Scepter": 10, "Air Scepter": 10, 
"Water Amulet":10,"Earth Amulet":10, 'Fire Amulet':10, "Air Amulet":10, 'Water Rune':10, 'Earth Rune':10, 'Fire Rune':10, 'Air Rune':10,
"Water Scroll":10, "Earth Scroll":10, "Fire Scroll":10, 'Air Scroll':10,
'Emerald':40, 'Amethyst':40, 'Ruby':40, 'Diamond':40, 'Aquamarine':40, 'Topaz':40,
"Adventurers Crown":120, "Miners Pick": 120, "Mages Robe": 120, "Alchemists Beaker":120, "Warriors Helm":120, "Copper":2, "Silver":5, "Gold":10}

points={'Fire Amulet':10, 
 'Ruby':40,
"Adventurers Crown":120,  "Copper":2, "Silver":5, "Gold":10}

def donateToMuseum(user, item):
  if 'museum'+str(user.id) not in db:
    db['museum'+str(user.id)]=[]
  if 'inv'+str(user.id) not in db:
    embed=discord.Embed(title='Error', color=0x2b9cec, description=f"No inventory found for user <!@{user.id}>. Go on an adventure using o-adventure.")
    return embed
  museum=db['museum'+str(user.id)]
  inventory=db['inv'+str(user.id)]
  if item in inventory:

      inventory.remove(item)
      museum.append(item)
      house=db['house'+str(user.id)]
      db[house]+=itemPoints[item]
      embed=discord.Embed(title="Item Donated", color=0x2b9cec, description=f"Item donated: {item}")
  else:
      embed=discord.Embed(title="Error", color=0x2b9cec, description=f"{item} not found in your inventory")
  db['museum'+str(user.id)]=museum
  db['inv'+str(user.id)]=inventory
  return embed





''''#def addHouse(username, house):
  houseDict=db["houses"]
  if str(username) in houseDict:
    return "Already added to a house"
  else:
    houseDict[str(username)]=house
    return "Sucessfully added to house of "  + house
  db["houses"]=houseDict
client=discord.Client()```'''

def counter(lst, x):
    count = 0
    for ele in lst:
        if (ele == x):
            count = count + 1
    return count

def checkPrice(item,m):
    #use gold first, then silver, then copper
    #create purchase function
    #list = db['Marketplace'].get('item')
    tiny = 1000000000
    mPrices = m
    li = mPrices[item]
    for k in range(0,len(li),2):
      if li[k] < tiny:
        tiny = li[k]
    return tiny
    

def addHouse(username, house):
  if 'house'+str(username) in db:
    return("Already added to house")
  else:
    db['house'+str(username)]=house
    return "Sucessfully added to house of " +house

def adventureReward():
  Artifact_list = ["Air Scepter","Earth Scepter","Fire Scepter",
	"Water Scepter","Air Amulet", "Earth Amulet","Fire Amulet",
	"Water Amulet","Air Scroll", "Earth Scroll","Fire Scroll",
	"Water Scroll","Air Rune","Earth Rune","Fire Rune","Water Rune"]
  Mineral_list = ["Ruby","Emerald","Aquamarine","Topaz","Diamond","Amethyst"]
  Currency = ["Copper","Silver"]
  RanList = [1,2,3,4,5,6,7,8,9,10]
  randomran = random.choice(RanList)
  Mineral_list = random.choice(Mineral_list)
  Artifact_list = random.choice(Artifact_list)
  Currency = random.choice(Currency)
  if randomran == 9 or randomran == 10:
    return Mineral_list
  elif randomran == 8 or randomran == 7:
    return Currency
  else:
    return Artifact_list
#adventureReward()

def goOnAdventure(user1, user2, reward, user2name):
  returnList=[]
  if 'house'+str(user1.id) in db:
    if 'inv'+str(user1.id) in db:
      lista=db['inv'+str(user1.id)]
      lista.append(reward)
      db['inv'+str(user1.id)]=lista
    else:
      db['inv'+str(user1.id)]=[]
      lista=db['inv'+str(user1.id)]
      lista.append(reward)
      db['inv'+str(user1.id)]=lista
    embed1=discord.Embed(title=f"Adventure {user1}", color=0x2b9cec, description=f"Congratulations! You received {reward}.")
    returnList.append(embed1)
    user1house=db['house'+str(user1.id)]
  else:
    embed1=discord.Embed(title=f"Error", color=0x2b9cec, description=f"No house found for user {user1}. Please use o-joinhouse to get started.")
    returnList.append(embed1)
  if 'house'+str(user2) in db:
    if 'inv'+str(user2) in db:
      lista=db['inv'+str(user2)]
      lista=db['inv'+str(user2)]
      lista.append(reward)
      db['inv'+str(user2)]=lista
    else:
      db['inv'+str(user2)]=[]
      lista=db['inv'+str(user2)]
      lista.append(reward)
      db['inv'+str(user2)]=lista
    #user = await client.fetch_user(int(user2))
    embed1=discord.Embed(title=f"Adventure {user2name}", color=0x2b9cec, description=f"Congratulations! You received {reward}.")
    returnList.append(embed1)
    user2house=db['house'+str(user2)]
    if user2house==user1house:
      houseReward=db[user2house]
      houseReward+=15
      db[user2house]=houseReward
      embed3=discord.Embed(Title="Bonus Reward", color=0x2b9cec, description=f"Points have been awarded to the house of {user2house} since both adventurers belong to that house.")
      returnList.append(embed3)
      print(db[user2house])
  else:
    embed1=discord.Embed(title=f"Error", color=0x2b9cec, description=f"No house found for user <@!{user2}>. Please use o-joinhouse to get started.")
    returnList.append(embed1)
  return returnList
 
def goOnAdventureSolo(user1, reward):
  returnList=[]
  if 'house'+str(user1.id) in db:
    if 'inv'+str(user1.id) in db:
      pass
    else:
      db['inv'+str(user1.id)]=[]
    lista=db['inv'+str(user1.id)]
    lista.append(reward)
    db['inv'+str(user1.id)]=lista
    embed1=discord.Embed(title=f"Solo Adventure {user1}", color=0x2b9cec, description=f"Congratulations! You received {reward}.")
    returnList.append(embed1)
    user1house=db['house'+str(user1.id)]
    houseReward=db[user1house]
    houseReward+=15
    db[user1house]=houseReward
    embed3=discord.Embed(Title="Bonus Reward", color=0x2b9cec, description=f"Points have been awarded to the house of {user1house} since the adventurer belongs to that house.")
    returnList.append(embed3)
      #print(db[user2house])
  else:
    embed1=discord.Embed(title=f"Error", color=0x2b9cec, description=f"No house found for user <@!{user2}>. Please use o-joinhouse to get started.")
    returnList.append(embed1)
  return returnList

def findUserId(mystr):
    mystr=mystr[:mystr.find('>')]
    mystr=mystr[mystr.find('!')+1:]
    return mystr

def go_market():
  pass

client=discord.Client()
@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))
    

@client.event
async def on_message(message):

    if message.author == client.user:
        return

    if message.content.startswith('o-hello'):
        await message.channel.send('Hello!')
    #if message.content.startswith('$house'):
        #await message.channel.send##(message.author.public_flags.hypesquad_balance)
    if message.content.startswith('o-house balance'):
      
      await message.channel.send(addHouse(message.author.id, "balance"))
    if message.content.startswith('o-house bravery'):
      
      await message.channel.send(addHouse(message.author.id, "bravery"))
    if message.content.startswith('o-house brilliance'):
      
      await message.channel.send(addHouse(message.author.id, "brilliance"))
    if message.content.startswith('o-checkhouse'):
      if 'house'+str(message.author.id) in db:
        await message.channel.send(db['house'+str(message.author.id)])
      else:

        embed=discord.Embed(title="Error", description=f"No house found for user {message.author}. Use o-joinhouse to select a house.", color=0x2b9cec)
        await message.channel.send(embed=embed)
    if message.content.startswith('o-info'):
      await message.channel.send(embed=discord.Embed(title="Okeanos", description="Welcome to Okeanos! The discord-based adventure game Okeanos enables players to collaborate with each other to explore the world of buying, selling, stealing, and crafting. One of our main inspirations while creating this game was the theme of discovery. As players play the game, they discover new ways to acquire points by adventuring, stealing, and crafting, allowing them to show their unique ingenuity to their teammates and opponents. We decided to use discord as our game engine for multiplayer capability and the opportunity to use it on any device. Using the discord bot allows players to collaborate seamlessly by going on artifact and mineral collecting adventures or enabling them to embark on an adventure by themself. While Okeanos is a collaborative game, it is indeed a race to conquer the leaderboard as well. By joining either the house of bravery, brilliance, or balance, you are committing to yourself and your team to adventure out, accumulate rewards, and achieve points. Good luck adventuring, and have fun! Select a house by typing o-joinhouse. Then, type o-gameactions to get started.", color=0x2b9cec))
    if message.content.startswith('o-joinhouse'):
      embed=discord.Embed(title="Join House", description="Respond with o-house bravery, o-house brilliance, or o-house balance to select your house. Choose wisely, as this cannot be changed later. We recommend taking the sorting test in Discord settings>HypeSquad.", color=0x2b9cec)
      embed.set_thumbnail(url="https://support.discord.com/hc/article_attachments/360009331331/Screen_Shot_2018-08-16_at_2.28.06_PM.png")
      await message.channel.send(embed=embed)
      '''
    if message.content.startswith('o-map'):
      embed=discord.Embed(title="Okeanos Map", description="Click the map icon to see enlarged map. ", url="https://raw.githubusercontent.com/23beraid/okeanos/main/mpa1.jpg")
      
      await message.channel.send(embed=embed)
      
    if message.content.startswith('o-emoji'):
      fireamulet = get(message.guild.emojis, name="fireamulet")
      wateramulet = get(message.guild.emojis, name="wateramulet")
      airamulet = get(message.guild.emojis, name="airamulet")
      earthamulet = get(message.guild.emojis, name="earthamulet")
      firerune = get(message.guild.emojis, name="firerune")
      earthrune = get(message.guild.emojis, name="earthrune")
      airrune = get(message.guild.emojis, name="airrune")
      waterrune = get(message.guild.emojis, name="waterrune")
      airscepter = get(message.guild.emojis, name="airscepter")
      waterscepter = get(message.guild.emojis, name="waterscepter")
      earthscepter = get(message.guild.emojis, name="earthscepter")
      firescepter = get(message.guild.emojis, name="firescepter")
      embed = discord.Embed(title=f"All Items", color=0x2b9cec, description=f"{wateramulet} Water Amulet \n {earthamulet} Earth Amulet \n {fireamulet} Fire Amulet \n {airamulet} Air Amulet\n{waterrune}Water Rune \n{earthrune} Earth Rune \n{firerune} Fire Rune\n{airrune} Air Rune\n{waterscepter} Water Scepter \n{earthscepter} Earth Scepter\n{firescepter} Fire Scepter \n{airscepter} Air Scepter")
      embed.add_field(name="Guildname", value=message.guild.id, inline=False)
      await message.channel.send(embed=embed)'''
    if message.content.startswith('o-inv'):
      if 'inv'+str(message.author.id) in db:

        inventory=db['inv'+str(message.author.id)]
        fstring=f""
        for x in inventory:
          emojiname=x.lower()
          emojiname=emojiname.replace(" ", "")
          #694901834695049327
          #fstring+=f"{get(message.guild.emojis, name=emojiname)}"
          guild = client.get_guild(694901834695049327)
          emoji = discord.utils.get(guild.emojis, name=emojiname)
          if emoji:
            fstring+=f"{emoji}"
          fstring+=f" "
          fstring+=str(x)
          fstring+= "\n"
        embed=discord.Embed(title=f"Inventory", color=0x2b9cec, description=fstring)
      else:
        embed=discord.Embed(title=f"Error", color=0x2b9cec, description=f"No inventory found for user {message.author}. Try going on an adventure using o-adventure!")
      await message.author.send(embed=embed)
    if message.content.startswith('o-museum'):
      if 'museum'+str(message.author.id) in db:

        inventory=db['museum'+str(message.author.id)]
        fstring=f""
        for x in inventory:
          emojiname=x.lower()
          emojiname=emojiname.replace(" ", "")
          guild = client.get_guild(694901834695049327)
          fstring+=f"{get(guild.emojis, name=emojiname)}"
          fstring+=f" "
          fstring+=str(x)
          fstring+= "\n"
        embed=discord.Embed(title=f"Musuem Items Donated", color=0x2b9cec, description=fstring)
        await message.channel.send(embed=embed)
      else:
        embed=discord.Embed(title=f"Error", color=0x2b9cec, description=f"No musuem donations found for user {message.author}. Try donating items by using o-donate <item>!")
        await message.channel.send(embed=embed)
    if message.content.startswith('o-adventure'):
      if 'inv'+str(message.author.id) in db:
        inventory=db['inv'+str(message.author.id)]
      else:
        inventory=[]
        #db['inv'+str(message.author.id)]=[]
      if str(message.content).__contains__('<@!'):
        user = await client.fetch_user(findUserId(str(message.content)))
        sendList=goOnAdventure(message.author, findUserId(str(message.content)), adventureReward(), user)

        for x in sendList:
          await message.channel.send(embed=x)
      elif "Adventurers Crown" in inventory:
        sendList=goOnAdventureSolo(message.author, adventureReward())
        for x in sendList:
          await message.channel.send(embed=x)
      else:
        embed=discord.Embed(title="Error", color=0x2b9cec,description=f"It's dangerous to go alone. Tag a friend by typing o-adventure @friend." )
        print(str(message.content))
        await message.channel.send(embed=embed)
    if message.content.startswith('o-help'):
      embed=discord.Embed(title="Okeanos Help", color=0x2b9cec, description="o-info gives information about the game \n o-gameactions gives a list of all game commands \n o-credits to view credits \n o-contact to contact the developers")
      await message.channel.send(embed=embed)
    if message.content.startswith('o-credits'):
      embed=discord.Embed(title="Credits", color=0x2b9cec, description="")
      embed.add_field(name="Backend", value="Sneha Dhital \n Jackson Eippert \n Aiden Golub", inline=False)
      embed.add_field(name="Frontend", value="Aidan Berard \nSneha Dhital", inline=False)
      embed.add_field(name="Art", value="Aidan Berard \n Jackson Eippert", inline=False)
      await message.channel.send(embed=embed)
    if message.content.startswith('o-gameactions'):
      embed=discord.Embed(title="Game Actions", color=0x2b9cec, description='')
      embed.add_field(name="Inventory", value="o-adventure @<player> to go on an adventure with a friend \no-adventure to go on a solo adventure (if  you have Adventurers Crown)\no-inv to see your inventory")
      embed.add_field(name="Market", value="o-market for help \n o-buy <item> to buy an item\n o-sell <item>, <price> to sell an item\n o-markin to see available items")
      embed.add_field(name="House", value="o-checkhouse to check your house\no-joinhouse to join a house\no-leaderboard to see current standings")
      embed.add_field(name="Utility", value="o-ag2cu to convert your silver to copper\no-au2cu to convert your gold to copper\no-craft <tool> to craft a tool\no-cu2ag to convert copper to silver \n o-ag2au to convert silver to gold\no-alchemy <input>, <output> to convert one mineral to another\n o-steal <item> from @someone to steal an item")
      embed.add_field(name="Museum", value="o-donate <item> to donate an item\no-museum to see all items you've donated\n o-combo <combo> to sell a combo to the museum")
      embed.add_field(name="Learning", value="o-items to learn about items\no-points to learn about points")

      await message.channel.send(embed=embed)
    if message.content.startswith('o-contact'):
      embed=discord.Embed(title="Credits", color=0x2b9cec, description="Reply with o-send <yourmessage> and we will send it to the developers!")
      await message.channel.send(embed=embed)

      #market
    if message.content.startswith('o-market'):
      embed=discord.Embed(title="Marketplace", color=0x2b9cec, description="This is the marketplace help screen.\n\nYou can buy some useful items from the market, not including copper, silver, or gold. Items can only be bought with copper. To see the inventory of items and prices, type 'o-markin'. To purchase an item from the market, type 'o-buy <item>'. To trade an item to the market, type 'o-sell <item>, <price (in units of copper)>'.")
      await message.author.send(embed=embed)
    if message.content.startswith('o-markin'):
      #emojis = message.guild.emojis
      guild = client.get_guild(694901834695049327)
      embed=discord.Embed(title="Market Inventory", color=0x2b9cec, description=display_items(guild))
      await message.author.send(embed=embed)
    if message.content.startswith('o-buy'):
      #gold and 1 copper vs 2 silver?? either way end up with 2 gold but first probs more useful if need points
      item = message.content[6:].lower()
      item = getItemB(item)
      a = str(message.author.id)
      m = db["Marketplace"]
      if item != "error":
        cp = checkPrice(item,m)
        if item in m and counter(db['inv'+a],'Copper')>=cp:
          #send message to seller
          embed=discord.Embed(title="Confirmed", color=0x2b9cec, description=f"Your item, " + item + ", has been sold for the price of " + str(cp) + " copper!")
          user = await client.fetch_user(int(get_seller(item,m)))
          buy_item(item,a,m)
          embed2=discord.Embed(title="Confirmed", color=0x2b9cec, description=f"You bought the item, " + item + " for the price of " + str(cp) + " copper!")
          await message.author.send(embed=embed2)
          await user.send(embed=embed)
          #purchase
        else:
          embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description=f"You do not have enough copper to purchase this item.")
          await message.author.send(embed=embed)
      else:
        embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description=f"The item is not in the market inventory. Type 'o-markin' to see the market inventory, and 'o-buy <item>' to buy an available item.")
        await message.author.send(embed=embed)
    if message.content.startswith('o-sell'):
      if any(x.isdigit() for x in message.content):
        if ", " not in message.content:
          embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description=f"You need to include a comma in your command.")
        else:
          sargs = message.content[7:].split(', ')
          sargs[1] = int(sargs[1])
          a = str(message.author.id)
          m = db["Marketplace"]
          if getItem(sargs[0]) == "Silver" or getItem(sargs[0]) == "Gold" or getItem(sargs[0]) == "Copper":
            embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description=f"You cannot sell copper, silver, or gold to the market.")
          elif 'inv'+a in db and getItem(sargs[0]) in db['inv'+a]:
            #if 'ordpla,'+a not in db:
              #db["ordpla," + a] = []
            #db["ordpla," + a] += [getItem(sargs[0]),sargs[1]]
            #db["Marketplace"] = con_m()
            db['inv'+a].remove(getItem(sargs[0]))
            embed=discord.Embed(title="Confirmed", color=0x2b9cec, description=f"{sell_item(sargs[0],sargs[1],a,m)}")
          else:
            embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description=f"You don't have that item! Don't try to sell something that is not in your inventory.")
        await message.author.send(embed=embed)
      else:
        embed=discord.Embed(title="Error",color=0x2b9cec, description=f"No price included. Type 'o-sell <item>, <price>' to sell your item.")
        await message.author.send(embed=embed)
    if message.content.startswith('o-leaderboard'):
      embed=discord.Embed(title="Leaderboard", color=0x2b9cec, description=f"House of Bravery: {db['bravery']}\n House of Brilliance: {db['brilliance']} \n House of Balance: {db['balance']}")
      await message.channel.send(embed=embed)

    #currency conversions
    if message.content.startswith('o-ag2cu'):
      a = str(message.author.id)
      if "Silver" in db['inv'+a]:
        embed=discord.Embed(title="Converted!", color=0x2b9cec, description=Convert1AgTo2Cu(db['inv'+a],a))
      else:
        embed=discord.Embed(title="o-no", color=0x2b9cec, description="You don't have any Silver!")
      await message.author.send(embed=embed)
    if message.content.startswith('o-au2cu'):
      a = str(message.author.id)
      if "Gold" in db['inv'+a]:
        embed=discord.Embed(title="Converted!", color=0x2b9cec, description=Convert1AuTo3Cu(db['inv'+a],a))
      else:
        embed=discord.Embed(title="o-no", color=0x2b9cec, description="You don't have any Gold!")
      await message.author.send(embed=embed)

    #combos
    if message.content.startswith('o-combo'):
      this=False
      if len(message.content) != 7 and len(message.content) != 8:
        a = message.author
        item = message.content[8:].lower()
        item = getItem(item)
        if item in elements:
          description = combineElements(a, item)
        elif item in items:
          description = combineItems(a, item)
        else:
          description = "Not a valid element or artifact. To see list of items, type 'o-items'."
      else:
        description="You need to specify which set of elements or artifacts you would like to donate for 4 gold. Type o-combo <element> or o-combo <artifact> to donate a set."
        this=True
      embed=discord.Embed(title="Combinations", color=0x2b9cec, description=description)
      if this==True:
        embed.add_field(name="Valid Combinations", value="o-combo water\no-combo earth\no-combo fire\no-combo air \n o-combo scepter \n o-combo amulet \n o-combo rune \n o-combo scroll")
      await message.author.send(embed=embed)

    #crafting
    if message.content.startswith('o-craft'):
      if len(message.content) == 7 or len(message.content) == 8:
        embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description="No tool specified! To craft a tool, you must type 'o-craft <tool>', where the tool is the last word. For example, if you would like to craft a Miner's Pick, type 'o-craft pick'.")
        embed.add_field(name=f"Information", value='See list below of all craftable items and the ingredients you need to craft them.')
        info=True
      else:
        info=False
        item = message.content[8:].lower()
        item = getItem(item)
        a = str(message.author.id)
        if item=="Crown":
          descript = CraftAdventurerscrown(db['inv'+a], [], [],a)
          embed=discord.Embed(title="Crafting", color=0x2b9cec, description=descript)
        elif item=="Robe":
          descript = CraftMagesrobe(db['inv'+a], [], [],a)
          embed=discord.Embed(title="Crafting", color=0x2b9cec, description=descript)
        elif item=="Helm":
          descript = CraftWarriorshelm(db['inv'+a], [], [],a)
          embed=discord.Embed(title="Crafting", color=0x2b9cec, description=descript)
        elif item=="Beaker":
          descript = CraftAlchemistsbeaker(db['inv'+a], [], [],a)
          embed=discord.Embed(title="Crafting", color=0x2b9cec, description=descript)
        elif item=="Pick":
          descript = CraftMinerspick(db['inv'+a], [], [],a)
          embed=discord.Embed(title="Crafting", color=0x2b9cec, description=descript)
        else:
          embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description="Not a valid tool. To craft a tool, you must type 'o-craft <tool>', where the tool is the last word. For example, if you would like to craft a Miner's Pick, type 'o-craft pick'.")
          embed.add_field(name=f"Information", value='See list below of all craftable items and the ingredients you need to craft them.')
          info=True
      await message.author.send(embed=embed)
      if info==True:
        await message.author.send(embed=getInfo(client))

    #stealing
    #StealfromVictim(Victiminv,Inventory,userid,a,item):
    if message.content.startswith('o-steal'):
      mc = message.content
      a = str(message.author.id)
      user = await client.fetch_user(findUserId(str(mc)))
      v = str(user.id)
      await message.delete() 
      if len(mc) != 7 and len(mc) != 8:
        if ' from ' in mc and str(mc).__contains__('<@!'):
          sargs = mc[8:].split(' from ')
          sargs[0] = getItem(sargs[0])
          if 'inv'+v not in db:
            db['inv'+v] = []
          if 'inv'+a not in db:
            db['inv'+a] = []
          description=StealfromVictim(db['inv'+v],db['inv'+a],v,a,sargs[0])
          if description==("You successfully stole the " + sargs[0] + "!"):
            embedV=embed=discord.Embed(title="Item Stolen!", color=0x2b9cec, description="Sadly, your " + sargs[0] + " has been stolen since you do not possess a Mage's Robe.")
            #user = await client.fetch_user(int(v))
            await user.send(embed=embedV)
          embed=discord.Embed(title="Steal Item", color=0x2b9cec, description=description)
        else:
          description="You need to include the victim you would like to steal from by typing 'o-steal <item> from <victim>'."
          embed=discord.Embed(title="Steal Item", color=0x2b9cec, description=description)
      else:
        description="You need to specify the item you would like to steal. Type 'o-steal <item> from <victim>' to attempt to steal an item that may or may not be in the victim's inventory."
      embed=discord.Embed(title="Steal Item", color=0x2b9cec, description=description)
      await message.author.send(embed=embed)

    if message.content.startswith('o-donate'):
      i = message.content[8:]
      if i.strip():
        await message.channel.send(embed=donateToMuseum(message.author, getItem(i)))
        
      else:

        embed=discord.Embed(title=f"Error", color=0x2b9cec, description=f"Please specify item to donate using o-donate <item>")
        await message.channel.send(embed=embed)
    if message.content.startswith('o-username'):
      await message.channel.send(str(client.get_user(int(message.author.id))))
    if message.content.startswith('o-send'):
      a=message.content[6:]
      for x in [392430116942381057,566378980396236841, 651526007039328256, 748226711258136676]:
        user = await client.fetch_user(x)
        await user.send(f"Message from {message.author}:")
        await user.send(a)
    if message.content.startswith('o-points'):
      guild = client.get_guild(694901834695049327)
      fstring=f""
      for  key, value in points.items():
        emojiname=key.lower()
        emojiname=emojiname.replace(" ", "")
        emoji = discord.utils.get(guild.emojis, name=emojiname)
        if emoji:
          fstring+=f"{emoji}"
        fstring+=f" {key} "
        
        if value==10 and key!="Gold":
          fstring+=f"(or another artifact) "
        elif value==40:
          fstring+=f"(or another mineral) "
        elif value==120:
          fstring+=f"(or another tool) "
        else:
          fstring+=f""
        fstring+=f" has a value of {value} \n"

      embed=discord.Embed(title="Points", color=0x2b9cec, description=f"Each item has a point value and points will be earned for donating these items to the museum." )
      embed.add_field(name='All Items', value=fstring)
      await message.author.send(embed=embed)
    if message.content.startswith('o-items'):
      embed=discord.Embed(title="Items", color=0x2b9cec, description="The game contains 16 artifacts and 6 minerals to discover. You can craft minerals into 5 unique tools (type o-craft to learn more). There are also three types of currency (copper, silver, and gold) where one gold is worth three copper and one silver is worth two copper.")
      await message.author.send(embed=embed)
      #list of items
      guild = client.get_guild(694901834695049327)
      embed=discord.Embed(title="Items List", color=0x2b9cec, description='')
      allarts = ""
      for x in range(0,16):
        allarts += allItems(guild)[x]
      embed.add_field(name="Artifacts", value=allarts)
      allmins = ""
      for x in range(16,22):
        allmins += allItems(guild)[x]
      embed.add_field(name="Minerals", value=allmins)
      alltools = ""
      for x in range(22,27):
        alltools += allItems(guild)[x]
      embed.add_field(name="Tools", value=alltools)
      allcurr = ""
      for x in range(27,30):
        allcurr += allItems(guild)[x]
      embed.add_field(name="Currency", value=allcurr)
      await message.author.send(embed=embed)

    if message.content.startswith('o-cu2ag'):
      a=str(message.author.id)
      if "Miners Pick" in db['inv'+a]:
        if "Copper" in db['inv'+a]:
          embed=discord.Embed(title="Converted!", color=0x2b9cec, description=ConvertCu2Ag(db['inv'+a],a))
        else:
          embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description="You don't have any Copper!")
        #inventory=db['inv'+str(message.author.id)]
      else:
        embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description="You need a Miner's Pick to turn copper into silver.")
      await message.author.send(embed=embed)
    if message.content.startswith('o-ag2au'):
      a=str(message.author.id)
      if "Miners Pick" in db['inv'+a]:
        if "Silver" in db['inv'+a]:
          embed=discord.Embed(title="Converted!", color=0x2b9cec, description=ConvertAg2Au(db['inv'+a],a))
        else:
          embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description="You don't have any Silver!")
        #inventory=db['inv'+str(message.author.id)]
      else:
        embed=discord.Embed(title="Uh-oh", color=0x2b9cec, description="You need a Miner's Pick to turn silver into gold.")
      await message.author.send(embed=embed)

    if message.content.startswith('o-clear'):
      #clear
      db['Marketplace']={}
    if message.content.startswith('o-add'):
      db['inv651526007039328256']=['Diamond', 'Emerald', 'Water Scepter', 'Copper', 'Copper', 'Copper', 'Copper', 'Water Scroll', 'Diamond', 'Earth Amulet', 'Water Scepter', 'Silver', 'Silver', 'Ruby', 'Topaz', 'Amethyst', 'Aquamarine', 'Aquamarine', 'Fire Scroll', 'Fire Scepter', 'Fire Amulet', 'Fire Rune', 'Alchemists Beaker']
      db['inv392430116942381057']=['Diamond', 'Emerald', 'Water Scepter', 'Copper', 'Copper', 'Copper', 'Copper', 'Water Scroll', 'Diamond', 'Earth Amulet', 'Water Scepter', 'Silver', 'Silver', 'Ruby', 'Topaz', 'Amethyst', 'Aquamarine', 'Aquamarine', 'Fire Scroll', 'Fire Scepter', 'Fire Amulet', 'Fire Rune', 'Warriors Helm']
      embed=discord.Embed(title="Added", color=0x2b9cec, description="Items added inv748226711258136676")
      await message.channel.send(embed=embed)
    if message.content.startswith('o-del'):
      del db['inv748226711258136676']
    if message.content.startswith('o-keys'):
      embed=discord.Embed(title="Keys", color=0x2b9cec, description=str(keys))
      await message.channel.send(embed=embed)
    if message.content.startswith('o-alchemy'):
      a=str(message.content)[9:]


      inputa=a[:a.find(',')]
      outputa=a[a.find(',')+1:]
      inputa=inputa.lower().strip()
      outputa=outputa.lower().strip()
      print(inputa)
      print(outputa)
      embed=discord.Embed(title="Alchemy", color=0x2b9cec, description=doAlchemy(message.author, inputa, outputa))
      await message.channel.send(embed=embed)
      

keep_alive()
client.run(os.getenv('TOKEN'))


'''
      #misc
    if message.content.startswith('o-add'):
      db['inv748226711258136676']=['Diamond', 'Emerald', 'Water Scepter', 'Copper', 'Copper', 'Copper', 'Copper', 'Water Scroll', 'Diamond', 'Earth Amulet', 'Water Scepter', 'Silver', 'Silver', 'Ruby', 'Topaz', 'Amethyst', 'Aquamarine', 'Aquamarine', 'Fire Scroll', 'Fire Scepter', 'Fire Amulet', 'Fire Rune']
    if message.content.startswith('o-dbm'):
      #del db["ordpla,748226711258136676"]
      embed=discord.Embed(title="Test", color=0x2b9cec, description=str(db['Marketplace']))
      await message.channel.send(embed=embed)
    if message.content.startswith('o-test'):
      #del db["ordpla,748226711258136676"]
      db['inv748226711258136676']=['Diamond', 'Emerald', 'Water Scepter', 'Copper', 'Copper', 'Copper', 'Copper', 'Copper', 'Copper', 'Copper', 'Copper', 'Copper', 'Copper', 'Water Scroll', 'Diamond', 'Earth Amulet', 'Water Scepter']
      db['inv392430116942381057']=['Fire Rune', 'Emerald', 'Water Scepter', 'Copper', 'Copper', 'Water Scroll', 'Copper', 'Emerald','Copper', 'Copper', 'Copper', 'Copper', 'Copper', 'Amethyst']
      embed=discord.Embed(title="Test", color=0x2b9cec, description=str(keys)+str(db['ordpla,748226711258136676']))
      await message.channel.send(embed=embed)
    if message.content.startswith('o-id'):
      embed=discord.Embed(title="Test", color=0x2b9cec, description=db["ordpla," + str(message.author.id)])
      await message.channel.send(embed=embed)
    if message.content.startswith('o-keys'):
      embed=discord.Embed(title="Keys", color=0x2b9cec, description=str(keys))
      await message.channel.send(embed=embed)
    if message.content.startswith('o-clear'):
      #clear
      db['Marketplace']={}
    if message.content.startswith('o-printm'):
      embed=discord.Embed(title="market", color=0x2b9cec, description=str(db['Marketplace']))
      await message.channel.send(embed=embed)
    if message.content.startswith('o-printi'):
      embed=discord.Embed(title="inv", color=0x2b9cec, description=str(db['inv748226711258136676']))
      await message.channel.send(embed=embed)
      embed=discord.Embed(title="inv", color=0x2b9cec, description=str(db['inv392430116942381057']))
      await message.channel.send(embed=embed)

keep_alive()
client.run(os.getenv('TOKEN'))
'''
