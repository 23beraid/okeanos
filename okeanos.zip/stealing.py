from replit import db
import discord
from discord.utils import get

def StealfromVictim(Victiminv,Inventory,userid,a,item):
  Victiminv=db['inv'+userid]
  Inventory=db['inv'+a]
  if item in Victiminv:
    if "Mages Robe" not in Victiminv:
      if "Warriors Helm" in Inventory:
        for x in Victiminv:
          if x == item:
            Inventory.append(x)
            Victiminv.remove(x)
            return "You successfully stole the " + item + "!"
            break
      else:
        return "You need a Warrior's Helm to steal."
    else:
      return "The player cannot be stolen from because they possess a Mage's Robe."
  else:
    return "The player does not possess the item. Sadly, your efforts have brought you no advantage as your luck is lacking in this instance."
#StealfromVictim(Victiminv,Inventory,userid)