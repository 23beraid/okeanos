from replit import db
import discord
from discord.utils import get
info={'Adventurers Crown':['Ruby', 'Aquamarine', 'Amethyst'], 'Mages Robe':['Emerald','Diamond', 'Topaz'], 'Warriors Helm':['Amethyst', "Emerald", 'Ruby'], 'Miners Pick':['Diamond', 'Emerald', 'Ruby'], 'Alchemists Beaker':["Topaz", 'Aquamarine', 'Diamond']}
#CI=[]
#Inventory=db['inv'+str(message.author.id)]

def UniqueGen(UI, Inventory):
  for x in Inventory:
    if x not in UI:
      UI.append(x)
def CraftAdventurerscrown(Inventory, UI, CI,a):
  UniqueGen(UI, Inventory)
  if "Ruby" in Inventory:
    CI.append("Ruby")
    i=0
    for x in UI:
      if x=="Aquamarine":
        CI.append(x)
      elif x=="Amethyst":
        CI.append(x)
    if len(CI)<3:
      CI.clear()
      return "You lack the necessary minerals"
    else:
      for x in CI:
        Inventory.remove(x)
      CI.clear()
      Inventory.append("Adventurers Crown")
      db['inv'+a] = Inventory
      return "You have sucessfuly crafted an Adventurer's Crown"
  else:
    return "You lack a Ruby"
def CraftMagesrobe(Inventory, UI, CI,a):
  UniqueGen(UI, Inventory)
  if "Emerald" in Inventory:
    CI.append("Emerald")
    i=0
    for x in UI:
      if x=="Diamond":
        CI.append(x)
      elif x=="Topaz":
        CI.append(x)
    if len(CI)<3:
      CI.clear()
      return "You lack the necessary minerals"
    else:
      for x in CI:
        Inventory.remove(x)
      CI.clear()
      Inventory.append("Mages Robe")
      db['inv'+a] = Inventory
      return "You have sucessfuly crafted a Mage's Robe"
  else:
    return "You lack an Emerald"
def CraftWarriorshelm(Inventory, UI, CI,a):
  UniqueGen(UI, Inventory)
  if "Amethyst" in Inventory:
    CI.append("Amethyst")
    i=0
    for x in UI:
      if x=="Emerald":
        CI.append(x)
      elif x=="Ruby":
        CI.append(x)
    if len(CI)<3:
      CI.clear()
      return "You lack the necessary minerals"
    else:
      for x in CI:
        Inventory.remove(x)
      CI.clear()
      Inventory.append("Warriors Helm")
      db['inv'+a] = Inventory
      return "You have sucessfuly crafted a Warrior's Helm"
  else:
    return "You lack an Amethyst"
def CraftAlchemistsbeaker(Inventory, UI, CI,a):
  UniqueGen(UI, Inventory)
  for x in UI:
    if x=="Topaz":
      CI.append(x)
    elif x=="Aquamarine":
      CI.append(x)
    elif x=="Diamond":
      CI.append(x)
  if len(CI)<3:
    CI.clear()
    return "You lack the necessary minerals"
  else:
    for x in CI:
      Inventory.remove(x)
    CI.clear()
    Inventory.append("Alchemists Beaker")
    db['inv'+a] = Inventory
    return "You have sucessfuly crafted an Alchemist's Beaker"
def CraftMinerspick(Inventory, UI, CI,a):
  UniqueGen(UI, Inventory)
  print(UI)
  for x in UI:
    if x=="Diamond":
      CI.append(x)
    elif x=="Emerald":
      CI.append(x)
    elif x=="Ruby":
      CI.append(x)
  if len(CI)<3:
    CI.clear()
    return "You lack the necessary minerals"
  else:
    for x in CI:
      Inventory.remove(x)
    CI.clear()
    Inventory.append("Miners Pick")
    db['inv'+a] = Inventory
    return "You have sucessfuly crafted a Miner's Pick"
#print(CraftAdventurerscrown(Inventory, [], []))
#print(CraftMagesrobe(Inventory, [], []))
#CraftWarriorshelm(Inventory, [], [])
#CraftAlchemistsbeaker(Inventory, [], [])
#CraftMinerspick(Inventory, [], [])


def getInfo(client):
  guild = client.get_guild(694901834695049327)
  
  fstring=f""
  for x, y in info.items():
    emojiname=x.lower()
    emojiname=emojiname.replace(' ', '')
    emoji = discord.utils.get(guild.emojis, name=emojiname)
    fstring+=f"{emoji}"
    fstring+=f" {x} "
    for m in y:
      emojiname=m.lower()
      emoji=discord.utils.get(guild.emojis, name=emojiname)
      fstring+=f"{emoji} "
    fstring+=f"\n"
  embed=discord.Embed(title=f"Craftable Tools", color=0x2b9cec, description=fstring)
  embed.add_field(name="Information", value="The Adventurers Crown will allow you to embark on an adventure by yourself. \n The Mages Robe will protect your items from being stolen. \n The Warriors Helm will allow you to steal items from other players.\nThe Miners Pick will allow you to convert currency into more valuable currency.\nThe Alchemists Beaker will allow you to convert minerals into other minerals. ", inline=False)
  return embed
 